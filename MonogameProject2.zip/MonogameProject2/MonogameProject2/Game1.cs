﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    public class Game1 : Game
    {
        //Variablen
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        public SpriteFont saoFont;

        //private List<Obstacle> obstacleList = new List<Obstacle>();
        private List<Obstacle> münzenList = new List<Obstacle>();

        int numberOfMünzen = 1;


        int coins = 0;

        //Background
        //private List<Obstacle> backgroundList = new List<Obstacle>();
        //int numberOfBackground = 2;

        //Klassen
        private BaseClassObjects bco = new BaseClassObjects();
        private Player player = new Player();
        private Obstacle obst = new Obstacle();
        private Background backgroundClass = new Background();
        private PlayerUI playerUI = new PlayerUI();

        //---------------------------
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }








        protected override void Initialize()
        {
            //Game Größe
            _graphics.PreferredBackBufferWidth = 1920;
            _graphics.PreferredBackBufferHeight = 1080;
            _graphics.ApplyChanges();

            // TODO: Add your initialization logic here
            
            //Background
            backgroundClass.Initialize(new Vector2(960,540), 1f);

            //Life
            playerUI.Initialize(new Vector2(450, 100), 0.5f);

            //Player
            player.Initialize(new Vector2(400, 250),3f);

            //Münzen
            obst.Initialize(new Vector2(250, 450), 0.25f);

            //Obstacle

            base.Initialize();
        }










        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            backgroundClass.LoadContent(Content, "SuperMarioBox_01");
            playerUI.LoadContent(Content);

            // TODO: use this.Content to load your game content here
            player.LoadContent(Content);
            obst.LoadContent(Content, "Münze_Kirito1");


            for (int i = 0; i < numberOfMünzen; i++)
            {
                münzenList.Add(new Obstacle(new Vector2(200 + obst.GetTexture().Width * obst.GetScale() * 2 * i, 800 + obst.GetTexture().Height * obst.GetScale()),
                    obst.GetScale(), Content, "Münze_Kirito1"));

                //Font
                saoFont = Content.Load<SpriteFont>("SaoText");
            }
        }










        protected override void Update(GameTime gameTime)
        {
            playerUI.Update();

            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            // TODO: Add your update logic here

            player.Update(gameTime);
            obst.Update(gameTime);
            backgroundClass.Update(gameTime);

            foreach (Obstacle obst in münzenList) //Obstacles check if they collide with the player
            {
                obst.CheckCollision(player);
            }

            if (player.test == true)
            {
                münzenList.Clear();
                coins += 1;
                player.test = false;
            }
            
            base.Update(gameTime);
        }














        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Pink);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();

            //BackGround
            backgroundClass.Draw(_spriteBatch);
            //Player UI
            playerUI.Draw(_spriteBatch);


            player.Draw(_spriteBatch);
            obst.Draw(_spriteBatch);

            foreach (Obstacle box in münzenList)
            {
                box.Draw(_spriteBatch);
            }


            //Font
            _spriteBatch.DrawString(saoFont, "Coins: " + coins, new Vector2(10, 55), color: Color.Black);

            //Player Position
            _spriteBatch.DrawString(saoFont, "X: " + player.position.X.ToString(), new Vector2(10, 10), color: Color.Black);
            _spriteBatch.DrawString(saoFont, "Y: " + player.position.Y.ToString(), new Vector2(10, 25), color: Color.Black);

            //Debug
            _spriteBatch.DrawString(saoFont, "Current LifePoints: " + playerUI.currentLifepoins.ToString(), new Vector2(10, 100), color: Color.Black);
            
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
