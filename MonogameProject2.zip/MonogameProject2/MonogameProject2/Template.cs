﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class Template : BaseClassObjects
    {
        //Game1: private Template varName = new Template();

        //Variablen
        protected Texture2D varName;

        public override void Initialize(Vector2 pos, float _scale)
        {
            scale = _scale;
            position = pos;
        }

        public void LoadContent(ContentManager content)
        {

        }

        public void Update(SpriteBatch spriteBatch)
        {

        }

        protected void Draw(GameTime gameTime)
        {

        }
    }
}
