﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class Player : BaseClassObjects
    {

        //private Obstacle obst = new Obstacle();

        //variablen die nur den Spieler betreffen. Die komplette restliche Funktionalität wird
        //geerbt
        float runModifier;
        bool run = false;
        float baseSpeed = 2;
        float currentSpeed = 1;

        float jumpForce = 30f;
        float gravity = 9.81f;
        float acceleration = 0f;
        bool isJumping = false;
        Vector2 jumpStart = Vector2.Zero;

        int tempPos = 0;
        float elapseTime = 0;

        float floor = 900f;
        float leftBorder = 30f;
        float rightBorder = 1880;

        List<Texture2D> runList = new List<Texture2D>();
        List<Texture2D> attackList = new List<Texture2D>();

        List<Texture2D> vorneList = new List<Texture2D>();
        List<Texture2D> hintenList = new List<Texture2D>();
        List<Texture2D> rechtsList = new List<Texture2D>();
        List<Texture2D> linksList = new List<Texture2D>();

        bool keyStateW = false;
        bool keyStateA = false;
        bool keyStateS = false;
        bool keyStateD = false;

        private PlayerUI playerUI = new PlayerUI();

        public override void Initialize(Vector2 pos, float _scale)
        {
            scale = _scale;
            position = pos;
            runModifier = 2.5f;
        }

        public void LoadContent(ContentManager content)
        {
            //Läd alle Sprites
            for(int i = 1; i < 8; i++)
            {
                runList.Add(content.Load<Texture2D>("run" + i + ""));
                attackList.Add(content.Load<Texture2D>("attack" + i + ""));
            }

            sprite = runList[0];

            for (int i = 1; i < 4; i++)
            {
                vorneList.Add(content.Load<Texture2D>("Vorne" + i + ""));
                hintenList.Add(content.Load<Texture2D>("Hinten" + i + ""));
                rechtsList.Add(content.Load<Texture2D>("Rechts" + i + ""));
                linksList.Add(content.Load<Texture2D>("Links" + i + ""));
            }
            sprite = vorneList[0];
            sprite = hintenList[0];
            sprite = rechtsList[0];
            sprite = linksList[0];


        }

        public void Update(GameTime gameTime)
        {
            MovePlayer();
            GravityDown();
            CheckBorderCollision();

            KeyboardState keyBState = Keyboard.GetState();

            if (keyBState.IsKeyDown(Keys.Space))
            {
                if (isJumping != true)
                {
                    jumpStart = position;
                }

                isJumping = true;
            }

            elapseTime += (float)gameTime.ElapsedGameTime.TotalSeconds;

            //Rechts
            if (keyBState.IsKeyDown(Keys.D))
            {
                if (elapseTime >= 0.07f)
                {
                    if (tempPos >= 3)
                    {
                        tempPos = 0;
                    }
                    sprite = rechtsList[tempPos++];
                    elapseTime = 0;
                }
                keyStateD = true;
            }
            else if (keyStateD == true)
            {
                sprite = rechtsList[0];
                keyStateD = false;
            }

            //Links
            if (keyBState.IsKeyDown(Keys.A))
            {
                if (elapseTime >= 0.07f)
                {
                    if (tempPos >= 3)
                    {
                        tempPos = 0;
                    }
                    sprite = linksList[tempPos++];
                    elapseTime = 0;
                }
                keyStateA = true;
            }
            else if (keyStateA == true)
            {
                sprite = linksList[0];
                keyStateA = false;
            }

            //Up - Hinten
            if (keyBState.IsKeyDown(Keys.W))
            {
                if (elapseTime >= 0.07f)
                {
                    if (tempPos >= 3)
                    {
                        tempPos = 0;
                    }
                    sprite = hintenList[tempPos++];
                    elapseTime = 0;
                }
                keyStateW = true;
            }
            else if (keyStateW == true)
            {
                sprite = hintenList[0];
                keyStateW = false;
            }

            //Down - Vorne
            if (keyBState.IsKeyDown(Keys.S))
            {
                if (elapseTime >= 0.07f)
                {
                    if (tempPos >= 3)
                    {
                        tempPos = 0;
                    }
                    sprite = vorneList[tempPos++];
                    elapseTime = 0;
                }
                keyStateS = true;
            }
            else if(keyStateS == true)
            {
                sprite = vorneList[0];
                keyStateS = false;
            }


            Jump();
        }

        public void MovePlayer()
        {
            KeyboardState keyboarState = Keyboard.GetState();


            if (keyboarState.IsKeyDown(Keys.W))
            {
                position.Y -= currentSpeed;

                playerUI.currentLifepoins = playerUI.currentLifepoins - 10;
            }

            if (keyboarState.IsKeyDown(Keys.S))
            {
                position.Y += currentSpeed;

                playerUI.currentLifepoins = playerUI.currentLifepoins + 10;
            }

            if (keyboarState.IsKeyDown(Keys.A))
            {
                position.X -= currentSpeed;
            }

            if (keyboarState.IsKeyDown(Keys.D))
            {
                position.X += currentSpeed;
            }

            //rennen wir?
            if (keyboarState.IsKeyDown(Keys.LeftShift))
            {
                run = true;
            }
            else
            {
                run = false;
            }

            if (run)
            {
                currentSpeed = baseSpeed * runModifier;
            }
            else
            {
                currentSpeed = baseSpeed;
            }
        }

        public void Jump()
        {
            if (isJumping == true)
            {
                gravity++;//Proxy für erhöhung durch zeit

                acceleration = -jumpForce + gravity; //* GameTime. + weil der Canvas nach unten größere Zahlen zeigt

                position.Y += acceleration;

                if (position.Y >= jumpStart.Y)
                {
                    position.Y = jumpStart.Y;
                    acceleration = 0;
                    isJumping = false;
                    gravity = 9.81f;
                }
            }

        }

        public void GravityDown()
        {
            if (isJumping == false)
            {
                gravity++;
                acceleration = gravity;
                position.Y += acceleration;
            }
            if (position.Y > floor)
            {
                position.Y = floor;
            }
        }
        public bool test = false;
        public void PushAway(Vector2 direction, float force)
        {
            position += direction * force;

            
            test = true;       
            
        }

        public void CheckBorderCollision()
        {
            if (position.X <= leftBorder)
            {
                position.X = leftBorder;
            }
            else if (position.X >= rightBorder)
            {
                position.X = rightBorder;
            }
        }

        //--> refactoring in the Obstacle klasse -> chekc auf Kollision mit Spieler
        public void CheckCollision(List<Obstacle> münzenList)
        {
            //Soll eine Liste prüfen, ob er mit irgendeinem Objekt aus der Liste kollidiert
            foreach (var hindernis in münzenList)
            {
                //Check distance
                //Wenn  die Distanz zum Objekt                          <= Breite :2  des objekts         + spieler breite :2  dann Kollision
                if (Vector2.Distance(position, hindernis.GetPosition()) <= hindernis.GetTexture().Width / 2 + sprite.Width * scale / 2.3)
                {
                    position += Utility.CalcDirection(position, hindernis.GetPosition()) * currentSpeed;

                }
            }
        }
        //<---
        //------------------------------------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------------------------------------ 
    }
}
