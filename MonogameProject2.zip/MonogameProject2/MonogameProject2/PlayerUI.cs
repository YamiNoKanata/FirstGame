﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class PlayerUI : BaseClassObjects
    {
        //Game1: private Template varName = new Template();

        //Variablen
        public List<Texture2D> lifeLineList = new List<Texture2D>();

        //------------------
        bool keyStateF = false;
        int tempPos = 0;
        float elapseTime = 0;

        public int currentLifepoins;
        //int maxLifepoins;






        public override void Initialize(Vector2 pos, float _scale)
        {
            scale = _scale;
            position = pos;

            //currentLifepoins = maxLifepoins;
            currentLifepoins = 50;
        }






        public void LoadContent(ContentManager content)
        {
            for (int i = 0; i < 10; i++)
            {
                lifeLineList.Add(content.Load<Texture2D>("lifeLine" + i + ""));
            }
            sprite = lifeLineList[0];
    }






        public void Update(SpriteBatch spriteBatch)
        {
            if (currentLifepoins > 90 && currentLifepoins <= 100)
            {
                sprite = lifeLineList[0];
            }
            else if (currentLifepoins > 80 && currentLifepoins <= 90)
            {
                sprite = lifeLineList[1];
            }
            else if (currentLifepoins > 70 && currentLifepoins <= 80)
            {
                sprite = lifeLineList[2];
            }
            else if (currentLifepoins > 60 && currentLifepoins <= 70)
            {
                sprite = lifeLineList[3];
            }
            else if (currentLifepoins > 50 && currentLifepoins <= 60)
            {
                sprite = lifeLineList[4];
            }
            else if (currentLifepoins > 40 && currentLifepoins <= 50)
            {
                sprite = lifeLineList[5];
            }
            else if (currentLifepoins > 30 && currentLifepoins <= 40)
            {
                sprite = lifeLineList[6];
            }
            else if (currentLifepoins > 20 && currentLifepoins <= 30)
            {
                sprite = lifeLineList[7];
            }
            else if (currentLifepoins > 10 && currentLifepoins <= 20)
            {
                sprite = lifeLineList[8];
            }
            else if (currentLifepoins > 0)
            {
                sprite = lifeLineList[9];
            }

            if (currentLifepoins > 100)
            {
                currentLifepoins = 100;
            }
            if (currentLifepoins < 0)
            {
                currentLifepoins = 0;
            }
        }

        
        
        
        
        
        protected void Draw(GameTime gameTime)
        {

        }
    }
}
