﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class Utility
    {
        public static Texture2D grasTiles;

        public static Random rand = new Random();
        public static Vector2 CalcDirection(Vector2 pos1, Vector2 pos2)
        {
            float dirX = 0;

            float dirY = 0;

            dirX = pos1.X - pos2.X;
            dirY = pos1.Y - pos2.Y;

            Vector2 distance = new Vector2(dirX, dirY);

            //Durch Normalization erhalten wir den Richtungsvektor
            return Vector2.Normalize(distance);
        }
    }
}
