﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class Background : BaseClassObjects
    {
        //Variablen
        private Texture2D _backgroundTexture;

        public override void Initialize(Vector2 pos, float _scale)
        {
            scale = _scale;
            position = pos;
        }

        public void Update(GameTime gameTime)
        {
            
        }
    }
}
