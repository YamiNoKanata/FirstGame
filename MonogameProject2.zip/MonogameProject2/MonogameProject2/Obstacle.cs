﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class Obstacle : BaseClassObjects
    {
        private Player player = new Player();

        //Variablen
        protected Texture2D obstBox;

        public Obstacle()
        {

        }

        public override void Initialize(Vector2 pos, float _scale)
        {
            scale = _scale;
            position = pos;
        }

        public void Update(GameTime gameTime)
        {
            sprite = obstBox;
            scale = 0.05f;

            position.Y = 825;
            //position.X = ;
        }

        public Obstacle(Vector2 pos, float scale, ContentManager content, string spriteName)
        {
            Initialize(pos, scale);
            LoadContent(content, spriteName);
        }

        public void CheckCollision(Player player)
        {
            //Check distance               
            if (Vector2.Distance(position, player.GetPosition()) <=
            player.GetTexture().Width * player.GetScale() / 2.3 + sprite.Width * scale / 2)
            {
                Vector2 direction = Utility.CalcDirection(player.GetPosition(), position);
                float pushForce = 0.5f;
                player.PushAway(direction, pushForce);
            }

        }
    }
}
