﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameProject2
{
    class BaseClassObjects
    {

        public Vector2 position;
        public Texture2D sprite;
        protected float scale;
        protected int layer;

        

        public virtual void Initialize(Vector2 pos, float _scale)
        {
            scale = _scale;
            position = pos;
        }
        public virtual void LoadContent(ContentManager content, string spriteName)
        {
            sprite = content.Load<Texture2D>(spriteName);
        }
        public virtual void Update()
        {

        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {

            if (sprite != null)
            {
                spriteBatch.Draw(sprite, position, null, Color.White, 0,
                    new Vector2(sprite.Width / 2, sprite.Height / 2),
                    scale, SpriteEffects.None, 1);
            }
        }


        public Texture2D GetTexture()
        {
            return sprite;
        }
        public Vector2 GetPosition()
        {
            return position;
        }

        public float GetScale()
        {
            return scale;
        }
    }
}
